package com.example.loginregister_mysql_volley;

public class DbContract {
    public static final String SERVER_LOGIN_URL = "http://192.168.1.7/loginRegister_mysql_volley_api/checkLogin.php";
    public static final String SERVER_REGISTER_URL = "http://192.168.1.7/loginRegister_mysql_volley_api/createData.php";
}
